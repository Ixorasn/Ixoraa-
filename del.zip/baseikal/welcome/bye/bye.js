const bye =  ` BYE`
exports.bye = bye
const bugmenu =  ` 
° Owner  : 6281228792751
° Version : 12
° Baileys : 4.4.0
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
😈 ${botname} 👿
[ VIP 1 ]
┏━━⊱
┣❏🌷 628xxx
┣❏santet 628xxx
┣❏sendtrol 628xxx
┣❏sendtrol2 628xxx
┣❏senddocu 628xxx
┣❏sendduc 628xxx
┣❏sendlokas 628xxx
┣❏sendlokas2 628xxx
┣❏sendinvite 628xxx
┣❏sendbuglist 628xx
┗━━⊱
[ contoh 🌷 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
[ VIP 2 ]
┏━━⊱
┣❏🌹 12637xxx
┗━━⊱
[ contoh 🌹 12637xxx ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
[ JADI BUG ]
┏━━⊱
┣❏Jadijago [ Text nya ]
┣❏Jadipolling [ Text nya ]
┣❏Jaditroli [ Text nya ]
┣❏Jadilokas [ Text nya ]
┣❏Jadidarknes [ Text nya ]
┣❏Jadidocu [ Text nya ]
┣❏Jadibuginvite [ Text nya ]
┣❏Jadibugpayment [ Text nya ]
┣❏Jadibugsw [ Text nya ]
┣❏Jadibugbutton [ Text nya ]
┣❏Jadivirtext1 [ Text nya ]
┣❏Jadivirtext2 [ Text nya ]
┣❏Jadivirtext3 [ Text nya ]
┣❏Jadivirtext4 [ Text nya ]
┣❏Jadivirtext5 [ Text nya ]
┣❏Jadivirtext6 [ Text nya ]
┣❏Jadivirtext7 [ Text nya ]
┣❏Jadivirtext8 [ Text nya ]
┣❏Jadivirtext9 [ Text nya ]
┣❏Jadivirtext10 [ Text nya ]
┗━━⊱
[ Contoh Jadijago Ixora ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
[ VIRTEXT DELAY ]
┏━━⊱
┣❏virtext1 [ jumlah ]
┣❏virtext2 [ jumlah ]
┣❏virtext3 [ jumlah ]
┣❏virtext4 [ jumlah ]
┣❏virtext5 [ jumlah ]
┣❏virtext6 [ jumlah ]
┣❏virtext7 [ jumlah ]
┣❏virtext8 [ jumlah ]
┣❏virtext9 [ jumlah ]
┣❏virtext10 [ jumlah ]
┗━━⊱
[ Contoh Virtext1 5 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
[ BONUS ]
┏━━⊱
┣❏🌷 [ jumlah ]
┣❏🦖 [ jumlah ]
┣❏🦕 [ jumlah ]
┣❏👿 [ jumlah ]
┣❏⚡ [ jumlah ]
┣❏🐉 [ jumlah ]
┣❏💥 [ jumlah ]
┣❏🍂 [ jumlah ]
┣❏🌪️ [ jumlah ]
┣❏virtext10 [ jumlah ]
┣❏Button [ Jumlah ]
┣❏Jadikatalog [reply sticker] jumlahnya
┣❏Jagoan [ reply chat target ]
┣❏Sange [ Harus Menjadi Admin ]
┗━━⊱`
exports.bugmenu = bugmenu
const menu =  ` 
° Owner  : ＩＸＯＲＡ Ｖ.２
° Version : 12
° Baileys : 4.4.0
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
 ❍ BUG_MENU ❍
┏━━⊱
┣❏ Bugmenu
┗━━⊱
 ❍ ALL_MENU ❍
┏━━⊱
┣❏ Allmenu
┗━━⊱
❍ MENU_MODS ❍
┏━━⊱
┣❏ Tiktok
┣❏ Listjualan
┣❏ Belajarkita
┣❏ Jasarun
┣❏ Methodeband
┣❏ Afk
┣❏ Ping
┣❏ Owner
┣❏ Listwibu
┣❏ Nowa 628xxx
┣❏ Verif 62xxx
┣❏ User add 62xx
┣❏ User del 62xxx
┣❏ Setcmd [ reply sticker ]
┣❏ Delcmd [ reply sticker ]
┗━━⊱
❍ MENU_GROUP ❍
┏━━⊱
┣❏ Antilink on / off
┣❏ Welcome on / off
┣❏ Detectadmin on / off
┣❏ Kick 628xxx
┣❏ Add 628xxx
┣❏ Promote 628xx
┣❏ Demote 628xx
┗━━⊱
ＩＸＯＲＡ Ｖ.２`
exports.menu = menu